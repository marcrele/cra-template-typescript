# cra-template-typescript
A create react app template with basic redux rest and graphql functionality.
